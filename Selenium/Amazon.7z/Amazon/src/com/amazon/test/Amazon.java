package com.amazon.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//add product to cart
public class Amazon {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\sts-bundle\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

		//open amazon
		driver.get("https://www.amazon.com/");

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//click on Departments
		driver.findElement(By.id("nav-link-shopall")).click();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//click on Lightning
		driver.findElement(By.xpath("//*[@id=\"a-page\"]/div[1]/div/div[2]/div[1]/div/a[1]")).click();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//click on Bulb to be added to cart 
		driver.findElement(By.xpath("//*[@id=\"result_0\"]/div/div/div/div[2]/div[1]/div[1]/a")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//add to Cart
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//open cart
		driver.findElement(By.xpath("//*[@id=\"hlb-view-cart-announce\"]")).click();
	}
}
