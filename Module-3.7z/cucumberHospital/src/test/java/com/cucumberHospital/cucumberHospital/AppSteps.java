package com.cucumberHospital.cucumberHospital;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AppSteps {
	private App app = new App();

	@Given("^to find patient (.*) by patient id$")
	public void to_find_patient_by_patient_id(String name) throws Throwable {
		app.setName(name);
	}

	@When("^patient id is (\\d+)$")
	public void patient_id_is(int arg1) throws Throwable {
		app.setId(arg1);
	}
	
	@Then("^patient (.*) with id (\\d+) founded$")
	public void patient_vinod_with_id_founded(String name,int arg1) throws Throwable {
		assertThat(name, is(app.getName()));
		assertThat(app.getPatientId(), is(true));
	}

}
