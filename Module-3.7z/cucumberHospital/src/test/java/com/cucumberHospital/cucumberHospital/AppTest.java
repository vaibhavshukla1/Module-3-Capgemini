package com.cucumberHospital.cucumberHospital;

import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;

/**
 * Unit test for simple App.
 */
@RunWith(Cucumber.class)
public class AppTest {
}
