package com.cucumberEmployee.cucumberEmployee;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AppSteps {

	App app = new App();

	@Given("^to find employee (.*) by employee code$")
	public void to_find_employee_vaibhav_by_employee_code(String name) throws Throwable {
		app.setEmployeename(name);
	}

	@When("^employeecode is (\\d+)$")
	public void employeecode_is(int arg1) throws Throwable {
		app.setEmployeeid(arg1);
	}

	@Then("^employee (.*) is founded with employeecode (\\d+)$")
	public void employee_vaibhav_is_founded_with_employeecode(String name, int arg1) throws Throwable {
		assertThat(name, is(app.getEmployeename()));
		assertThat(app.getEmployee(), is(true));
	}

}
