package com.cucumberEmployee.cucumberEmployee;

public class App {
	private String employeename;
	private int employeeid;
	private String employeecode;

	public String getEmployeename() {
		return employeename;
	}

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}

	public String getEmployeecode() {
		return employeecode;
	}

	public void setEmployeecode(String employeecode) {
		this.employeecode = employeecode;
	}

	public boolean getEmployee() {
		if (this.employeeid==1) {
			return true;
		}
		return false;
	}
}
