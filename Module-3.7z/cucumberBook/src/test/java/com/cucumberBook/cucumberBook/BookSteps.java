package com.cucumberBook.cucumberBook;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BookSteps {
	private App app=new App();
	
	@Given("^that the user want to find book (.*) by book id$")
	public void that_the_user_Vaibhav_want_to_find_book_by_book_id(String name) throws Throwable {
	    app.setName(name);
	}

	@When("^user entered (\\d+)$")
	public void user_entered(int arg1) throws Throwable {
	    app.setId(arg1);
	}

	@Then("^user founded book (.*) with id (\\d+)$")
	public void vaibhav_founded_book_with_id(String name,int arg2) throws Throwable {
	    assertThat(name, is(app.getName()));
	    assertThat(app.getBook(), is(true));
	}

}
