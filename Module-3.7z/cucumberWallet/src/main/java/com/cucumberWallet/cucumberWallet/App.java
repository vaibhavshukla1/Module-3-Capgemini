package com.cucumberWallet.cucumberWallet;

public class App {
	private String mobile;
	private int balance;
	private String name;

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean getMobilleNumber() {
		if (this.mobile.equals("9598016816") || this.mobile.equals("7388317917")) {
			return true;
		}
		return false;
	}

}
