package com.cucumberWallet.cucumberWallet;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WalletSteps {

	private App app = new App();

	@Given("^to find (.*) is registered with balance (\\d+)$")
	public void that_vaibhav_is_registered_with_balance(int arg1, String name) throws Throwable {
		app.setName(name);
		app.setBalance(arg1);
	}

	@When("^mobile number entered \"([^\"]*)\"$")
	public void mobile_number_entered(String arg2) throws Throwable {
		app.setMobile(arg2);
	}

	@Then("^(.*) is founded with mobile number \"([^\"]*)\" and balance (\\d+)$")
	public void vaibhav_is_founded_eith_mobile_number_and_balance(String name,String arg1, int arg2) throws Throwable {
		assertThat(name, is(app.getName()));
		assertThat(app.getMobilleNumber(), is(true));
	}

}
